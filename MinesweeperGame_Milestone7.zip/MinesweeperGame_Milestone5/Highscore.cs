﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Almicke "Mickey" Navarro
//CST227
//November 16, 2018
//This is my own work with the help of Emily Quevedo, docs.microsoft.com/en-us/dotnet/api/system.icomparable?view=netframework-4.7.2 & github.com/aaronfonseca/
namespace MinesweeperGame_Milestone5
{
    //extend this class to IComparable to be use the mehtod to compare highscores 
    //THIS IS THE PLAYERSTATS CLASS
    class Highscore : IComparable<Highscore>
    {
        //getters and setters 
        public String Name { get; set; }
        public String Level { get; set; }
        public TimeSpan Score { get; set; }

        //constructor
        public Highscore(String Name, String Level, TimeSpan Score)
        {
            this.Name = Name;
            this.Level = Level;
            this.Score = Score;
        }
        
        //method to compare the scores of the players 
        public int CompareTo(Highscore other)
        {
            return Score.CompareTo(other.Score);
        }
    }
}
