﻿namespace MinesweeperGame_Milestone5
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.diff_btn = new System.Windows.Forms.RadioButton();
            this.mod_btn = new System.Windows.Forms.RadioButton();
            this.easy_btn = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.button1.Location = new System.Drawing.Point(232, 258);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 46);
            this.button1.TabIndex = 9;
            this.button1.Text = "Start Game";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(376, 31);
            this.label1.TabIndex = 8;
            this.label1.Text = "Choose your level of difficulty:";
            // 
            // diff_btn
            // 
            this.diff_btn.AutoSize = true;
            this.diff_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.diff_btn.Location = new System.Drawing.Point(12, 175);
            this.diff_btn.Name = "diff_btn";
            this.diff_btn.Size = new System.Drawing.Size(72, 29);
            this.diff_btn.TabIndex = 7;
            this.diff_btn.TabStop = true;
            this.diff_btn.Text = "Hard";
            this.diff_btn.UseVisualStyleBackColor = true;
            // 
            // mod_btn
            // 
            this.mod_btn.AutoSize = true;
            this.mod_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.mod_btn.Location = new System.Drawing.Point(12, 115);
            this.mod_btn.Name = "mod_btn";
            this.mod_btn.Size = new System.Drawing.Size(100, 29);
            this.mod_btn.TabIndex = 6;
            this.mod_btn.TabStop = true;
            this.mod_btn.Text = "Medium";
            this.mod_btn.UseVisualStyleBackColor = true;
            // 
            // easy_btn
            // 
            this.easy_btn.AutoSize = true;
            this.easy_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.easy_btn.Location = new System.Drawing.Point(12, 57);
            this.easy_btn.Name = "easy_btn";
            this.easy_btn.Size = new System.Drawing.Size(74, 29);
            this.easy_btn.TabIndex = 5;
            this.easy_btn.TabStop = true;
            this.easy_btn.Text = "Easy";
            this.easy_btn.UseVisualStyleBackColor = true;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 316);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.diff_btn);
            this.Controls.Add(this.mod_btn);
            this.Controls.Add(this.easy_btn);
            this.Name = "Menu";
            this.Text = "Menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Menu_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton diff_btn;
        private System.Windows.Forms.RadioButton mod_btn;
        private System.Windows.Forms.RadioButton easy_btn;
    }
}

