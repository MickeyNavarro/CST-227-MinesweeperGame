﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Almicke "Mickey" Navarro
//CST227
//November 16, 2018
//This is my own work with the help of Emily Quevedo, docs.microsoft.com/en-us/dotnet/api/system.windows.forms.textbox.scrollbars?view=netframework-4.7.2 & stackoverflow.com/questions/13900441/c-sharp-read-txt-file-into-textbox & github.com/aaronfonseca/ & stackoverflow.com/questions/5853073/change-the-textbox-height & stackoverflow.com/questions/7105230/how-to-access-the-files-in-bin-debug-within-the-project-folder-in-visual-studio
namespace MinesweeperGame_Milestone5
{
    public partial class ShowHighscores : Form
    {
        //create a string to hold the level of difficulty the user chose  
        public string difficulty;
        //create a timespan valuse for the elasped time it took for the user won the game
        public TimeSpan score;
        //create a bool to check if the user was a winnner
        public bool win;

        //create a list of highscores based on level
        private List<Highscore> Easy = new List<Highscore>();
        private List<Highscore> Medium = new List<Highscore>();
        private List<Highscore> Hard = new List<Highscore>();

        //create a string to locate the highscores text file
        public static string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        string fullPath = Path.Combine(path, "Highscores.txt");

        public ShowHighscores()
        {
            InitializeComponent();
        }

        //method to initialize a new highscore from game play
        public ShowHighscores(string difficulty, TimeSpan score, bool win)
        {
            //read the line from the external highscore file
            foreach (string line in File.ReadLines(fullPath))
            {
                //split line by comma
                var values = line.Split(',');

                //add new highscore depnding on level
                if (values[1] == "Easy")
                {
                    Easy.Add(new Highscore(values[0], values[1], TimeSpan.Parse(values[2])));
                }
                else if (values[1] == "Medium")
                {
                    Medium.Add(new Highscore(values[0], values[1], TimeSpan.Parse(values[2])));
                }
                else if (values[1] == "Hard")
                {
                    Hard.Add(new Highscore(values[0], values[1], TimeSpan.Parse(values[2])));
                }

            }

            this.difficulty = difficulty; 
            this.score = score;
            this.win = win;
            InitializeComponent();
        }

        //method to load the ShowHighscores form
        private void ShowHighscores_Load(object sender, EventArgs e)
        {
            //display your score onto the form
            YourScore_Label.Text = "Your score: " + String.Format("{0:00}:{1:00}:{2:00}", score.Hours, score.Minutes, score.Seconds);
            
            //add vertical scroll bars to each text box & expand the height to match the tab page
            textBox_all.ScrollBars = ScrollBars.Vertical;
            this.textBox_all.AutoSize = false;
            this.textBox_all.Size = new System.Drawing.Size(385, 287);

            textBox_easy.ScrollBars = ScrollBars.Vertical;
            this.textBox_easy.AutoSize = false;
            this.textBox_easy.Size = new System.Drawing.Size(385, 287);

            textBox_med.ScrollBars = ScrollBars.Vertical;
            this.textBox_med.AutoSize = false;
            this.textBox_med.Size = new System.Drawing.Size(385, 287);

            textBox_hard.ScrollBars = ScrollBars.Vertical;
            this.textBox_hard.AutoSize = false;
            this.textBox_hard.Size = new System.Drawing.Size(385, 287);

            //create strings to hold the text for each textbox
            string output_easy = "";
            string output_med = "";
            string output_hard = "";
            string output_all = "";

            //sort each list by scores
            Easy.Sort();
            Medium.Sort();
            Hard.Sort();

            //add the scores to its specific string to using LINQ statements
            foreach (var stat in Easy)
            {
                output_easy += stat.Name + ": " + stat.Level + " " + String.Format("{0:00}:{1:00}:{2:00}", stat.Score.Hours, stat.Score.Minutes, stat.Score.Seconds) + Environment.NewLine + Environment.NewLine;
            }
            foreach (var stat in Medium)
            {
                output_med += stat.Name + ": " + stat.Level + " " + String.Format("{0:00}:{1:00}:{2:00}", stat.Score.Hours, stat.Score.Minutes, stat.Score.Seconds) + Environment.NewLine + Environment.NewLine;
            }
            foreach (var stat in Hard)
            {
                output_hard += stat.Name + ": " + stat.Level + " " + String.Format("{0:00}:{1:00}:{2:00}", stat.Score.Hours, stat.Score.Minutes, stat.Score.Seconds) + Environment.NewLine + Environment.NewLine;
            }
            output_all = output_hard + output_med + output_easy;

            //add the score its specific textbox
            textBox_easy.Text = output_easy;
            textBox_med.Text = output_med;
            textBox_hard.Text = output_hard;
            textBox_all.Text = output_all; 
        }


        //submit button 
        private void button1_Click(object sender, EventArgs e)
        {
            //check if the player was a winner
                //if yes, add their score to the highscore list 
            if (win == true)
            {
                if (difficulty == "Easy")
                {
                    //add submitted winner score to highscore list
                    Easy.Add(new Highscore(Name_Text.Text, difficulty, score));
                    //sort by score
                    Easy.Sort();
                    
                }
                else if (difficulty == "Medium")
                {
                    //add submitted winner score to highscore list
                    Medium.Add(new Highscore(Name_Text.Text, difficulty, score));
                    //sort by score
                    Medium.Sort();
                }
                else if (difficulty == "Hard")
                {
                    //add submitted winner score to highscore list
                    Hard.Add(new Highscore(Name_Text.Text, difficulty, score));
                    //sort by score
                    Hard.Sort();
                }
                
            }
            //if no, don't allow a submission
            else
            {
                MessageBox.Show("Sorry! You must win to submit your score!"); 
            }

            //create string to hold a comma
            string split = ",";
            //create a new list to hold the updated highscores
            List<string[]> updatedHS = new List<string[]>();

            //add the updated highscores to the new list
            for (var i = 0; i < 5; i++)
            {
                updatedHS.Add(new string[] { Easy[i].Name, Easy[i].Level, String.Format("{0:00}:{1:00}:{2:00}", Easy[i].Score.Hours, Easy[i].Score.Minutes, Easy[i].Score.Seconds)});
            }
            for (var i = 0; i < 5; i++)
            {
                updatedHS.Add(new string[] { Medium[i].Name, Medium[i].Level, String.Format("{0:00}:{1:00}:{2:00}", Medium[i].Score.Hours, Medium[i].Score.Minutes, Medium[i].Score.Seconds) });
            }
            for (var i = 0; i < 5; i++)
            {
                updatedHS.Add(new string[] { Hard[i].Name, Hard[i].Level, String.Format("{0:00}:{1:00}:{2:00}", Hard[i].Score.Hours, Hard[i].Score.Minutes, Hard[i].Score.Seconds) });
            }

            //count how many highscores are in the new list
            int length = updatedHS.Count;

            //add the new list of updated highscores to the file (reuse the old highscore file & just rewrite it)
            using (System.IO.TextWriter writer = File.CreateText(fullPath))
            {
                for (int index = 0; index < length; index++)
                {
                    writer.WriteLine(string.Join(split, updatedHS[index]));
                }
            }

            //reload the form with all of the updated highscores
            //create strings to hold the text for each textbox
            string output_easy = "";
            string output_med = "";
            string output_hard = "";
            string output_all = "";

            //empty the lists to add the new updated file without adding to the old lists of scores
            Easy.Clear();
            Medium.Clear();
            Hard.Clear(); 

            //read the lines from the UPDATED external highscore file
            foreach (string line in File.ReadLines(fullPath))
            {
                //split line by comma
                var values = line.Split(',');

                //add new highscore depnding on level
                if (values[1] == "Easy")
                {
                    Easy.Add(new Highscore(values[0], values[1], TimeSpan.Parse(values[2])));
                }
                else if (values[1] == "Medium")
                {
                    Medium.Add(new Highscore(values[0], values[1], TimeSpan.Parse(values[2])));
                }
                else if (values[1] == "Hard")
                {
                    Hard.Add(new Highscore(values[0], values[1], TimeSpan.Parse(values[2])));
                }

            }

            //add the scores to its specific string to using LINQ statements
            foreach (var stat in Easy)
            {
                output_easy += stat.Name + ": " + stat.Level + " " + String.Format("{0:00}:{1:00}:{2:00}", stat.Score.Hours, stat.Score.Minutes, stat.Score.Seconds) + Environment.NewLine + Environment.NewLine;
            }
            foreach (var stat in Medium)
            {
                output_med += stat.Name + ": " + stat.Level + " " + String.Format("{0:00}:{1:00}:{2:00}", stat.Score.Hours, stat.Score.Minutes, stat.Score.Seconds) + Environment.NewLine + Environment.NewLine;
            }
            foreach (var stat in Hard)
            {
                output_hard += stat.Name + ": " + stat.Level + " " + String.Format("{0:00}:{1:00}:{2:00}", stat.Score.Hours, stat.Score.Minutes, stat.Score.Seconds) + Environment.NewLine + Environment.NewLine;
            }
            output_all = output_hard + output_med + output_easy;

            //add the score its specific textbox
            textBox_easy.Text = output_easy;
            textBox_med.Text = output_med;
            textBox_hard.Text = output_hard;
            textBox_all.Text = output_all;
        }
    }
}
