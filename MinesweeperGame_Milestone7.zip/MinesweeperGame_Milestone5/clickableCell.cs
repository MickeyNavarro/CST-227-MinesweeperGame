﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Almicke "Mickey" Navarro
//CST227
//October 18, 2018 (update November 6, 2018)
//This is my own work with the help of Emily Quevedo, CST117's tic toc game & github.com/aaronfonseca/
namespace MinesweeperGame_Milestone5
{
    public class clickableCell : Button
    {
        //attributes combined with Milestone 4's cell class attributes
        private double row;
        private double column;
        private bool visited;
        private bool live;
        private int numOfNeighbors;

        //set initial count of the button clicks to 0 
        public int count = 0;

        //constructor
        public clickableCell()
        {
            //set the default color, text, etc. of the cell 
            this.BackColor = Color.Yellow;
            this.Text = "";
            this.setRow(-1);
            this.setColumn(-1);
            this.setVisited(false);
            this.setLive(false);
            this.setNumOfNeighbors(0);
        }

        //setters
        public void setCount()
        {
            this.count = this.count + 1;
        }
        public void setRow(double row)
        {
            this.row = row;
        }
        public void setColumn(double column)
        {
            this.column = column;
        }
        public void setVisited(bool visited)
        {
            this.visited = visited;
        }
        public void setLive(bool live)
        {
            this.live = live;
        }
        public void setNumOfNeighbors(int neighbors)
        {
            this.numOfNeighbors = neighbors;
        }

        //getters
        public int getCount()
        {
            return this.count;
        }
        public double getRow()
        {
            return this.row;
        }
        public double getColumn()
        {
            return this.column;
        }
        public bool getVisited()
        {
            return this.visited;
        }
        public bool getLive()
        {
            return this.live;
        }
        public int getNumOfNeighbors()
        {
            return this.numOfNeighbors;
        }

        //create a public instance of the game 
        public Game gridOfCells;

        //method to essentially pass on the game made from the program  
        public void passGame(Game gs)
        {
            gridOfCells = gs;
        }

        //method to reveal if the clickable cell is live or not
        public void revealGame(Game gs)
        {
            gs.revealGrid();
        }

        //method to revale the clickable cell's with no live neighbors 
        public void revealZerosGame(Game gs)
        {
            gs.revealZeros(Convert.ToInt32(this.getRow()), Convert.ToInt32(this.getColumn()));
        }

        //method to check if all the cells have been visited &/or the game is over
        public void checkVistitedGame(Game gs)
        {
            gs.checkVisited();
        }

        //method to reveal the non live neighbors 
        public void revealNonLive()
        {
            //checks if cell has any live neighbors 
            //if yes, the cell will output the number of live neighbors
            //if no, the cell will output an empty cell 
            if (this.getNumOfNeighbors() > 0)
            {
                this.Text = Convert.ToString(this.getNumOfNeighbors());
                this.BackColor = Color.Lavender;
            }
            else
            {
                this.Text = "";
                this.BackColor = Color.Lavender;

            }
        }

        //method to override onclick method for button class
        protected override void OnClick(EventArgs e)
        {
            //empty out this method so that we could use the mouse buttons

        }
        
        //allows the buttons to have different actions for the right and left click 
        protected override void OnMouseDown(MouseEventArgs e)
        {
            switch (MouseButtons)
            {
                // On Left Mouse Click
                case MouseButtons.Left:
                    //checks if you hit a bomb
                    if (this.getNumOfNeighbors() == 9)
                    {
                        //set to false to not throw off the visitedCells count in the game class
                        this.setVisited(false);
                        //stop timer
                        gridOfCells.sw.Stop();
                        //get the elapsed time as a timespan value
                        TimeSpan ts = gridOfCells.sw.Elapsed;
                        //reveal the bombs of the grid
                        revealGame(gridOfCells);
                        //output that that game is over
                        MessageBox.Show("GAME OVER! " + "Time Elasped: " + ts);
                        // bool for win or lose
                        bool win = false;
                        //create a new instance of the highscore form & display it 
                        ShowHighscores hs = new ShowHighscores(gridOfCells.difficulty, ts, win);
                        hs.Show();
                    }
                    //checks if you hit a cell without any live neighbors
                    else if (this.getNumOfNeighbors() == 0)
                    {
                        this.setVisited(true);
                        this.BackColor = Color.Lavender;
                        revealZerosGame(gridOfCells);
                    }
                    //checks if you hit any other cell
                    else if (this.getNumOfNeighbors() > 0)
                    {
                        this.setVisited(true);
                        this.BackColor = Color.Lavender;
                        this.Text = Convert.ToString(this.getNumOfNeighbors());
                    }
                    checkVistitedGame(gridOfCells);
                    break;

                // On Right Mouse Click
                case MouseButtons.Right:
                    // change text
                    this.Text = "";
                    // Assign an image to the button.
                    this.Image = new Bitmap(Image.FromFile(Path.Combine(Environment.CurrentDirectory, "greenflag.jpg")), new Size(25, 25));
                    break;
            }
        }

    }
}
