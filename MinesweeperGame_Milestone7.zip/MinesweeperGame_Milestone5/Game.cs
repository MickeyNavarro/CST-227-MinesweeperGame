﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Almicke "Mickey" Navarro
//CST227
//October 18, 2018 (update November 6, 2018)
//This is my own work with the help of Emily Quevedo, CST117's tic toc game & github.com/aaronfonseca/
namespace MinesweeperGame_Milestone5
{
    public partial class Game : Form
    {
        //create array of clickableCells to set up the grid for the game
            //creating an array will allow us to use our past code from the other milestones because the game was created as an array 
        private clickableCell[,] gridOfCells;

        //create a string to get the difficultly level from the menu 
        public string difficulty = "";

        //create a string to hold the size of the grid 
        public int gridSize = 0;

        //create a stopwatch to record the time of play 
        public Stopwatch sw = new Stopwatch();

        //create a public bool to check if the player had won
        public bool win = false; 
        
        //constructor
        public Game(string difficultly)
        {
            InitializeComponent();

            //set the difficulty level 
            this.difficulty = difficultly;
        }

        //method to load the game form 
        private void Game_Load(object sender, EventArgs e)
        {
            //start the timer 
            sw.Start(); 

            //allow the form to be autosized 
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;

            //change the difficulty string to an int
            if (difficulty == "Easy")
            {
                gridSize = 1;
            }
            else if (difficulty == "Medium")
            {
                gridSize = 2;
            }
            else if (difficulty == "Hard")
            {
                gridSize = 3;
            }
            //use difficulty to set size of game grid
            gridSize = gridSize * 5;

            //create another array of clickableCells to set up the grid for the game
            gridOfCells = new clickableCell[gridSize, gridSize];

            //create a loop to create game grid
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    //create new clickable cell button
                    gridOfCells[i, j] = new clickableCell();
                    //set the attributes of the button on the form 
                    int x = j * 35;
                    int y = i * 35;
                    gridOfCells[i, j].Location = new Point(x, y);
                    gridOfCells[i, j].Size = new Size(35, 35);
                    gridOfCells[i, j].setRow(i);
                    gridOfCells[i, j].setColumn(j);
                    //pass the game on to the clickable cell class
                    gridOfCells[i, j].passGame(this);
                    //add the new button to the game 
                    Controls.Add(gridOfCells[i, j]);
                }
            }

            activateLive();
            countLiveNeighbors();
        }

        //method to choose a random percentage of cells to become live
        private void activateLive()
        {
            //create a random percentage between 15-20 % to create live cells 
            Random rand = new Random();
            double percent = rand.Next(15, 20);
            percent = percent / 100;

            //find the complete cell count 
            double numOfCells = gridSize * gridSize;

            //find the number of cells that will be live 
                //must use 'double' due to to the method of 'Round'
            double ranCount = Math.Round(numOfCells * percent, 0);

            //create an array of ints to hold the number of random live cells 
            int[] ranLive = new int[Convert.ToInt32(ranCount)];

            //create a loop to turn the cells live
            for (int actCells = 0; actCells < ranCount; actCells++)
            {
                //generate a random cell from the gridOfCells
                double cellLive = rand.Next(0, Convert.ToInt32(numOfCells));

                //create an int to search the index of the ranLive array for the number of cellLive
                int pos = Array.IndexOf(ranLive, cellLive);

                //check if the array if the lower bound was found (meaning if the number was found within the array already)
                    //if yes, do not add the value to the array 
                    //if no, add the value to the array
                if (pos>-1)
                {
                    return; 
                }
                else
                {
                    ranLive[actCells] = Convert.ToInt32(cellLive);
                }
                
            }

            //Loop to make cells live.
            int liveCounter = 0;
            for (int i = 0; i < gridOfCells.GetLength(0); i++)
            {
                for (int j = 0; j < gridOfCells.GetLength(0); j++)
                {
                    if (ranLive.Contains(liveCounter))
                    {
                        gridOfCells[i, j].setLive(true);
                    }
                    liveCounter++;
                }
            }
        }

        //method to count each cells' live neighbors
        private void countLiveNeighbors()
        {
            //create an int to count the live neighbors of each cell 
            int liveNeighborCounter = 0;

            //create a loop to check every cell 
            for (int i = 0; i < gridOfCells.GetLength(0); i++)
            {
                for (int j = 0; j < gridOfCells.GetLength(0); j++)
                {
                    liveNeighborCounter = 0;
                    bool cellVal = gridOfCells[i, j].getLive();
                    if (cellVal == false)
                    {
                        //check left cell
                        if (i > 0)
                        {
                            bool val = gridOfCells[i - 1, j].getLive();
                            if (val)
                            {
                                liveNeighborCounter++;
                            }
                        }

                        //check right cell
                        if (i < gridOfCells.GetLength(0) - 1)
                        {
                            bool val = gridOfCells[i + 1, j].getLive();
                            if (val)
                            {
                                liveNeighborCounter++;
                            }
                        }

                        //check top cell
                        if (j > 0)
                        {
                            bool val = gridOfCells[i, j - 1].getLive();
                            if (val)
                            {
                                liveNeighborCounter++;
                            }
                        }

                        //check bottom cell
                        if (j < gridOfCells.GetLength(0) - 1)
                        {
                            bool val = gridOfCells[i, j + 1].getLive();
                            if (val)
                            {
                                liveNeighborCounter++;
                            }
                        }

                        //check top left cell
                        if ((i > 0) && (j > 0))
                        {
                            bool val = gridOfCells[i - 1, j - 1].getLive();
                            if (val)
                            {
                                liveNeighborCounter++;
                            }
                        }

                        //check top right cell 
                        if ((i < gridOfCells.GetLength(0) - 1) && (j > 0))
                        {
                            bool val = gridOfCells[i + 1, j - 1].getLive();
                            if (val)
                            {
                                liveNeighborCounter++;
                            }
                        }

                        //check bottom left cell
                        if ((i > 0) && (j < gridOfCells.GetLength(0) - 1))
                        {
                            bool val = gridOfCells[i - 1, j + 1].getLive();
                            if (val)
                            {
                                liveNeighborCounter++;
                            }
                        }

                        //check bottom right cell
                        if ((i < gridOfCells.GetLength(0) - 1) && (j < gridOfCells.GetLength(0) - 1))
                        {
                            bool val = gridOfCells[i + 1, j + 1].getLive();
                            if (val)
                            {
                                liveNeighborCounter++;
                            }
                        }
                        //set the number of live neighbors to the inactive cells 
                        gridOfCells[i, j].setNumOfNeighbors(liveNeighborCounter);
                    }
                    else
                    {
                        //set the number of live neighbors count to 9 if the cell is lice 
                        gridOfCells[i, j].setNumOfNeighbors(9);
                    }
                }
            }
        }

        //method to reveal the live and non-live cells 
        public virtual void revealGrid()
        {
            //create a loop to display which cells were “live” by displaying an asterisk in their place
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    //create a bool to get whether the cell is live or not 
                    bool cellValue = gridOfCells[i, j].getLive();

                    //check if cell isn't live
                    if (!cellValue)
                    {
                        gridOfCells[i, j].revealNonLive(); 
                    }
                    else
                    {
                        //change text to a picture to show if the cell was live
                        //gridOfCells[i, j].BackColor = Color.Red;
                        gridOfCells[i, j].Image = new Bitmap(Image.FromFile(Path.Combine(Environment.CurrentDirectory, "blackbomb.jpg")), new Size(30, 30));
                    }
                }
            }
        }

        //MILESTONE 3 - Use Recursion to Develop an Algorithm That Reveals Blocks of Cells With No Live Neighbors
            //method that reveals cell blocks with no live neighbors
            //needs input of cell block that was chosen 
        public void revealZeros(int i, int j)
        {
            //get cell value of whether it is live or not
            bool cellVal = gridOfCells[i, j].getLive();

            //check if the chosen cell was not live 
            if (cellVal == false)
            {
                //check if the cell has a neighbor to the left
                if (j > 0)
                {
                    //get the num of neighbors and the visit bool of the left neighbor
                    int leftNeighborsVal = gridOfCells[i, j-1].getNumOfNeighbors();
                    bool leftVisitVal = gridOfCells[i, j-1].getVisited();

                    //check if the left cell has not been visited
                    if (leftVisitVal == false)
                    {
                        //set cell to visited
                        gridOfCells[i, j-1].setVisited(true);

                        //reveal the non-live neighbors
                        gridOfCells[i, j-1].revealNonLive();


                        //check num of neighbors
                        if (leftNeighborsVal == 0)
                        {
                            revealZeros(i, j-1);
                        }
                    }
                }

                //check if the cell has a neighbor to the right
                if (i >= 0 && j < (gridSize-1))
                {
                    //get the num of neighbors and the visit bool of the right neighbor
                    int rightNeighborsVal = gridOfCells[i, j+1].getNumOfNeighbors();
                    bool rightVisitVal = gridOfCells[i, j+1].getVisited();

                    //check if the right cell has not been visited
                    if (rightVisitVal == false)
                    {
                        //set cell to visited
                        gridOfCells[i, j+1].setVisited(true);
                        //reveal the non-live neighbors
                        gridOfCells[i, j+1].revealNonLive();

                        //check num of neighbors
                        if (rightNeighborsVal == 0)
                        {
                            revealZeros(i, j+1);
                        }
                    }
                }

                //check if the cell has a top neighbor
                if (i > 0)
                {
                    //get the num of neighbors and the visit bool of the top neighbor
                    int topNeighborsVal = gridOfCells[i-1, j].getNumOfNeighbors();
                    bool topVisitVal = gridOfCells[i-1, j].getVisited();

                    //check if the left cell has not been visited
                    if (topVisitVal == false)
                    {
                        //set cell to visited
                        gridOfCells[i-1, j].setVisited(true);
                        //reveal the non-live neighbors
                        gridOfCells[i-1, j].revealNonLive();

                        //check num of neighbors
                        if (topNeighborsVal == 0)
                        {
                            revealZeros(i-1, j);
                        }
                    }
                }

                //check if the cell has a bottom neighbor
                if (i < (gridSize-1))
                {
                    //get the num of neighbors and the visit bool of the bottom neighbor
                    int bottomNeighborsVal = gridOfCells[i+1, j].getNumOfNeighbors();
                    bool bottomVisitVal = gridOfCells[i+1, j].getVisited();

                    //check if the left cell has not been visited
                    if (bottomVisitVal == false)
                    {
                        //set cell to visited
                        gridOfCells[i+1, j].setVisited(true);
                        //reveal the non-live neighbors
                        gridOfCells[i+1, j].revealNonLive();

                        //check num of neighbors
                        if (bottomNeighborsVal == 0)
                        {
                            revealZeros(i+1, j);
                        }
                    }
                }
            }
            //return nothing, but this will help indicate that the cells are not visited 
            return;
        }

        //method to check if the cells have been all visited or not 
            /*allows user to check certain cells for bombs until they visit all the cells or choose a 
            live cell*/
        public void checkVisited()
        {
            //create these ints to count the number of visited cells and to keep track how many nonlive cells need to be visited in order to win the game 
            int visitedCells = 0;
            int nonliveCells = 0; 

            //loop to check the grid for cells that are visited
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    //counts the visited cells 
                    if (gridOfCells[i, j].getVisited())
                    {
                        visitedCells++;
                    }
                    //counts the non live cells 
                    if (!gridOfCells[i, j].getLive())
                    {
                        nonliveCells++;
                    }
                }
            }
            //checks if you had won
            if (visitedCells == nonliveCells && sw.IsRunning)
            {
                //stop timer
                sw.Stop();
                //get the elapsed time as a timespan value
                TimeSpan ts = sw.Elapsed;
                //bool for win or lose
                win = true;
                //reveal the underlying grid of all the cells 
                revealGrid();
                //output that the user has won
                MessageBox.Show("CONGRATS! You have won! " + "Time Elasped: " + ts);
                //create a new instance of the highscore form & display it 
                ShowHighscores hs = new ShowHighscores(difficulty, ts, win);
                hs.Show();

            }
        }

    }
}
