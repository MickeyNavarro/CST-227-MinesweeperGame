﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
//Almicke "Mickey" Navarro
//CST227
//October 18, 2018 (update November 6, 2018)
//This is my own work with the help of Emily Quevedo, CST117's tic toc game & github.com/aaronfonseca/
namespace MinesweeperGame_Milestone5
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Menu());
        }
    }
}
