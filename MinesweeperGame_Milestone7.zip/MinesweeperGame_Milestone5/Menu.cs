﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Almicke "Mickey" Navarro
//CST227
//October 18, 2018
//This is my own work with the help of Emily Quevedo, CST117's tic toc game, stackoverflow.com/questions/24693942/c-sharp-close-all-forms & github.com/aaronfonseca/
namespace MinesweeperGame_Milestone5
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }
        private void Menu_Load(object sender, EventArgs e)
        {

        }

        //actions for when start button is clicked
        private void button1_Click(object sender, EventArgs e)
        {
            //checks which difficulty level was chosen, then creates a new form with the grid of the chosen difficulty
            if (easy_btn.Checked)
            {
                //create a string to pass on the difficulty level to the game form 
                string easy = "Easy";
                //create new form for the game grid
                Game game1 = new Game(easy);
                //show the new form 
                game1.Show();
            }
            else if (mod_btn.Checked)
            {
                //create a string to pass on the difficulty level to the game form 
                string mod = "Medium";
                //create new form for the game grid
                Game game2 = new Game(mod);
                //show the new form 
                game2.Show();
            }
            else if (diff_btn.Checked)
            {
                //create a string to pass on the difficulty level to the game form 
                string diff = "Hard";
                //create new form for the game grid
                Game game3 = new Game(diff);
                //show the new form 
                game3.Show();
            }
            //checks if no levels were selected
            else
            {
                //outputs to the user that they must choose a level
                MessageBox.Show("You must choose a level to begin the game!");
            }
        }

        //method to check if the form is closing 
        private void Menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check with if the user wants to exit the game
            if (e.CloseReason == CloseReason.UserClosing)
            {
                //check the user's option through a message box
                if (MessageBox.Show("Are you sure want to exit?",
                               "Minesweeper Game",
                                MessageBoxButtons.OKCancel,
                                MessageBoxIcon.Information) == DialogResult.OK)
                    Environment.Exit(1);
                else
                    //cancel the closing if they don't want to exit
                    e.Cancel = true;
            }

        }
    }
}
