﻿namespace MinesweeperGame_Milestone5
{
    partial class ShowHighscores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.YourScore_Label = new System.Windows.Forms.Label();
            this.Name_Text = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.easy_tab = new System.Windows.Forms.TabPage();
            this.med_tab = new System.Windows.Forms.TabPage();
            this.hard_tab = new System.Windows.Forms.TabPage();
            this.All = new System.Windows.Forms.TabPage();
            this.textBox_all = new System.Windows.Forms.TextBox();
            this.textBox_easy = new System.Windows.Forms.TextBox();
            this.textBox_med = new System.Windows.Forms.TextBox();
            this.textBox_hard = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.easy_tab.SuspendLayout();
            this.med_tab.SuspendLayout();
            this.hard_tab.SuspendLayout();
            this.All.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(141, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label2.Location = new System.Drawing.Point(129, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 31);
            this.label2.TabIndex = 9;
            this.label2.Text = "Highscores:";
            // 
            // YourScore_Label
            // 
            this.YourScore_Label.AutoSize = true;
            this.YourScore_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.YourScore_Label.Location = new System.Drawing.Point(12, 382);
            this.YourScore_Label.Name = "YourScore_Label";
            this.YourScore_Label.Size = new System.Drawing.Size(121, 25);
            this.YourScore_Label.TabIndex = 10;
            this.YourScore_Label.Text = "Your Score: ";
            // 
            // Name_Text
            // 
            this.Name_Text.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.Name_Text.Location = new System.Drawing.Point(17, 430);
            this.Name_Text.Name = "Name_Text";
            this.Name_Text.Size = new System.Drawing.Size(256, 30);
            this.Name_Text.TabIndex = 11;
            this.Name_Text.Text = "Enter your name here";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.button1.Location = new System.Drawing.Point(279, 426);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 39);
            this.button1.TabIndex = 12;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.All);
            this.tabControl1.Controls.Add(this.easy_tab);
            this.tabControl1.Controls.Add(this.med_tab);
            this.tabControl1.Controls.Add(this.hard_tab);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.tabControl1.Location = new System.Drawing.Point(17, 54);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(393, 325);
            this.tabControl1.TabIndex = 13;
            // 
            // easy_tab
            // 
            this.easy_tab.Controls.Add(this.textBox_easy);
            this.easy_tab.Location = new System.Drawing.Point(4, 34);
            this.easy_tab.Name = "easy_tab";
            this.easy_tab.Padding = new System.Windows.Forms.Padding(3);
            this.easy_tab.Size = new System.Drawing.Size(385, 287);
            this.easy_tab.TabIndex = 1;
            this.easy_tab.Text = "Easy";
            this.easy_tab.UseVisualStyleBackColor = true;
            // 
            // med_tab
            // 
            this.med_tab.Controls.Add(this.textBox_med);
            this.med_tab.Location = new System.Drawing.Point(4, 34);
            this.med_tab.Name = "med_tab";
            this.med_tab.Padding = new System.Windows.Forms.Padding(3);
            this.med_tab.Size = new System.Drawing.Size(385, 287);
            this.med_tab.TabIndex = 2;
            this.med_tab.Text = "Medium";
            this.med_tab.UseVisualStyleBackColor = true;
            // 
            // hard_tab
            // 
            this.hard_tab.Controls.Add(this.textBox_hard);
            this.hard_tab.Location = new System.Drawing.Point(4, 34);
            this.hard_tab.Name = "hard_tab";
            this.hard_tab.Padding = new System.Windows.Forms.Padding(3);
            this.hard_tab.Size = new System.Drawing.Size(385, 287);
            this.hard_tab.TabIndex = 3;
            this.hard_tab.Text = "Hard";
            this.hard_tab.UseVisualStyleBackColor = true;
            // 
            // All
            // 
            this.All.Controls.Add(this.textBox_all);
            this.All.Location = new System.Drawing.Point(4, 34);
            this.All.Name = "All";
            this.All.Padding = new System.Windows.Forms.Padding(3);
            this.All.Size = new System.Drawing.Size(385, 287);
            this.All.TabIndex = 4;
            this.All.Text = "All";
            this.All.UseVisualStyleBackColor = true;
            // 
            // textBox_all
            // 
            this.textBox_all.AllowDrop = true;
            this.textBox_all.Location = new System.Drawing.Point(0, 0);
            this.textBox_all.Multiline = true;
            this.textBox_all.Name = "textBox_all";
            this.textBox_all.Size = new System.Drawing.Size(385, 20);
            this.textBox_all.TabIndex = 0;
            // 
            // textBox_easy
            // 
            this.textBox_easy.Location = new System.Drawing.Point(0, 0);
            this.textBox_easy.Multiline = true;
            this.textBox_easy.Name = "textBox_easy";
            this.textBox_easy.Size = new System.Drawing.Size(385, 20);
            this.textBox_easy.TabIndex = 0;
            // 
            // textBox_med
            // 
            this.textBox_med.Location = new System.Drawing.Point(0, 0);
            this.textBox_med.Multiline = true;
            this.textBox_med.Name = "textBox_med";
            this.textBox_med.Size = new System.Drawing.Size(385, 20);
            this.textBox_med.TabIndex = 0;
            // 
            // textBox_hard
            // 
            this.textBox_hard.Location = new System.Drawing.Point(0, 0);
            this.textBox_hard.Multiline = true;
            this.textBox_hard.Name = "textBox_hard";
            this.textBox_hard.Size = new System.Drawing.Size(385, 20);
            this.textBox_hard.TabIndex = 0;
            // 
            // ShowHighscores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 477);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Name_Text);
            this.Controls.Add(this.YourScore_Label);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ShowHighscores";
            this.Text = "ShowHighscores";
            this.Load += new System.EventHandler(this.ShowHighscores_Load);
            this.tabControl1.ResumeLayout(false);
            this.easy_tab.ResumeLayout(false);
            this.easy_tab.PerformLayout();
            this.med_tab.ResumeLayout(false);
            this.med_tab.PerformLayout();
            this.hard_tab.ResumeLayout(false);
            this.hard_tab.PerformLayout();
            this.All.ResumeLayout(false);
            this.All.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label YourScore_Label;
        private System.Windows.Forms.TextBox Name_Text;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage All;
        private System.Windows.Forms.TabPage easy_tab;
        private System.Windows.Forms.TabPage med_tab;
        private System.Windows.Forms.TabPage hard_tab;
        private System.Windows.Forms.TextBox textBox_all;
        private System.Windows.Forms.TextBox textBox_easy;
        private System.Windows.Forms.TextBox textBox_med;
        private System.Windows.Forms.TextBox textBox_hard;
    }
}